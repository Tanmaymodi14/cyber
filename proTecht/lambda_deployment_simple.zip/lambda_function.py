import json

def lambda_handler(event, context):
    """
    AWS Lambda handler for proTecht API
    """
    
    # Parse the event
    http_method = event.get('httpMethod', 'GET')
    path = event.get('path', '')
    
    # Route the request
    if path == '/api/health':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps({
                "status": "healthy",
                "message": "proTecht API is running on AWS Lambda"
            })
        }
    
    elif path == '/api/controls':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps({
                "status": "success",
                "data": [
                    {"id": "AC-1", "status": "pass", "score": 85, "reasons": ["Policy in place"]},
                    {"id": "AC-2", "status": "pass", "score": 90, "reasons": ["Access controls configured"]},
                    {"id": "AC-3", "status": "fail", "score": 40, "reasons": ["Missing evidence"]},
                    {"id": "AC-4", "status": "pass", "score": 70, "reasons": ["WAF deployed"]},
                    {"id": "AC-7", "status": "pass", "score": 60, "reasons": ["Strong password policy"]},
                    {"id": "AC-10", "status": "pass", "score": 70, "reasons": ["SSO enabled"]},
                    {"id": "AC-16", "status": "pass", "score": 60, "reasons": ["S3 encryption enforced"]},
                    {"id": "AC-21", "status": "pass", "score": 60, "reasons": ["S3 public access blocked"]}
                ]
            })
        }
    
    elif path == '/api/evidence/aws/services':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps({
                "status": "success",
                "data": [
                    {
                        "id": "iam-config",
                        "title": "IAM Configuration",
                        "status": "Current",
                        "kpis": {"Users": 8, "Roles": 4, "Policies": 0}
                    },
                    {
                        "id": "s3-policies",
                        "title": "S3 Bucket Policies", 
                        "status": "Current",
                        "kpis": {"Buckets": 10, "PublicBuckets": 0, "Encrypted": 10, "ObjectLockBuckets": 7}
                    },
                    {
                        "id": "kms",
                        "title": "KMS",
                        "status": "Current", 
                        "kpis": {"Keys": 10, "RotationEnabled": 7}
                    },
                    {
                        "id": "cloudtrail",
                        "title": "CloudTrail",
                        "status": "Current",
                        "kpis": {"Trails": 3, "Events": 0, "RetentionDays": 90}
                    },
                    {
                        "id": "waf",
                        "title": "WAF",
                        "status": "Current",
                        "kpis": {"WebACLs": 3, "Blocked7d": 0}
                    },
                    {
                        "id": "guardduty",
                        "title": "GuardDuty",
                        "status": "Current",
                        "kpis": {"Detector": 1, "Critical/High": 0}
                    },
                    {
                        "id": "security-hub",
                        "title": "Security Hub",
                        "status": "Current",
                        "kpis": {"Enabled": "Yes", "OpenFindings": 201}
                    },
                    {
                        "id": "vpc-cloudfront",
                        "title": "VPC/CloudFront",
                        "status": "Current",
                        "kpis": {"FlowLogs": "On", "Distributions": 0, "TLSPolicy": "v1.2+"}
                    },
                    {
                        "id": "identity-center",
                        "title": "Identity Center (SSO)",
                        "status": "Current",
                        "kpis": {"PermissionSets": 0, "SessionTimeout": "PT8H", "MFA": "Enabled"}
                    },
                    {
                        "id": "aws-config",
                        "title": "AWS Config",
                        "status": "Current",
                        "kpis": {"RulesTotal": 4, "LockoutRules": 2}
                    }
                ]
            })
        }
    
    elif path == '/api/policies':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps({
                "status": "success",
                "data": [
                    {
                        "id": "policy-1758916848",
                        "name": "Test Small Policy",
                        "status": "Partial",
                        "controlsMapped": ["AC-1"],
                        "lastAnalyzed": "2025-09-27T05:30:00+00:00"
                    },
                    {
                        "id": "policy-1758916863", 
                        "name": "Test Small Policy 2",
                        "status": "Compliant",
                        "controlsMapped": ["AC-1", "AC-2"],
                        "lastAnalyzed": "2025-09-27T05:30:00+00:00"
                    },
                    {
                        "id": "policy-1758943060",
                        "name": "Policy_Permitted_Actions.pdf",
                        "status": "Compliant", 
                        "controlsMapped": ["AC-1", "AC-2", "AC-3"],
                        "lastAnalyzed": "2025-09-27T05:30:00+00:00"
                    }
                ]
            })
        }
    
    elif path.startswith('/api/policies/') and path.endswith('/reanalyze') and http_method == 'POST':
        policy_id = path.split('/')[-2]
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps({
                "status": "success",
                "message": f"Policy {policy_id} reanalyzed successfully",
                "data": {
                    "id": policy_id,
                    "name": "Test Policy",
                    "status": "Compliant",
                    "controlsMapped": ["AC-1", "AC-2"],
                    "lastAnalyzed": "2025-09-27T05:30:00+00:00"
                },
                "timestamp": "2025-09-27T05:30:00+00:00"
            })
        }
    
    elif path == '/api/evidence/aws/recollect' and http_method == 'POST':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': json.dumps({
                "status": "success", 
                "message": "AWS data collection started",
                "collected_keys": ["cloudtrail", "s3", "kms", "guardduty", "sso", "config", "vpc"],
                "timestamp": "2025-09-27T05:30:00+00:00"
            })
        }
    
    # Handle OPTIONS requests for CORS
    elif http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization'
            },
            'body': ''
        }
    
    # Default response
    else:
        return {
            'statusCode': 404,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                "error": "Not Found",
                "message": f"Path {path} not found"
            })
        }
