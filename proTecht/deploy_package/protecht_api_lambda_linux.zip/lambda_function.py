from mangum import Mangum
from api_server import app
handler = Mangum(app)
